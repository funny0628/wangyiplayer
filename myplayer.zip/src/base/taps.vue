<template>
  <div class="tap">
    <!-- <router-link></router-link> -->
    <div
      :class="{detailtabel:index === activeindex}"
      @click="changeclass(index)"
      v-for="(item, index) in taps"
      :key="index"
      class="taps"
    >
      {{ item.tap || item }}
    </div>
  </div>
</template>

<script>
export default {
  name: "Taps",
  props: ["taps", "classname"],
  data() {
    return {
      list: ["asdfsd", "sdfsd", "rtert", "yuyiyt"],
      activeindex: 0,
      aa:'default'
    };
  },
  methods: {
    changeclass(index) {
      this.activeindex = index;
    }
  }
};
</script>

<style lang="scss" scoped>
.tap {
  font-size: 16px;
  line-height: 60px;
  display: flex;
  justify-content: flex-end;
  .taps {
    cursor: pointer;
    margin-right: 30px;
    &.default {
      color: #d33a31;
    }
    
    &.detailtabel {
      color: #d33a31;
      border-bottom: 2px solid red;
    }
  }
}
</style>
