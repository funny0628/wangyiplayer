<template>
  <div class="miniplayer">
      
  </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
.miniplayer {
    width: 100vw;
    height: 66px;
    position: absolute;
   bottom: 0px;
   background-color: #fff;
   border-top: 2px solid #ccc;
}

</style>