<template>
  <div @click="toMvDetail" class="mvscard">
    <div class="image">
      <img :src="imageurl" alt="" />
      <span class="num"> <i class="iconfont icon-bofang1"></i> {{count}}</span>
      <Icon cssname="mvs" />
    </div>
    <p class="mvname">{{ songname }}</p>
    <p class="singername">{{artiname}}</p>
  </div>
</template>

<script>
export default {
  components: {
  },
  props: ["imageurl", "songname", "artiname","count","id"],
  methods: {
    toMvDetail(){
      this.$router.push(`/mv/${this.id}`)
    }
  }
};
</script>

<style lang="scss" scoped>
.mvscard {
  width: 275px;
  padding:20px 5px;
  cursor: pointer;
  .image {
    position: relative;
    img {
      width: 275px;
      height: 155px;
      border-radius: 10px;
    }
    .num {
      position: absolute;
      right: 5px;
      top: 10px;
      color: #fff;
    }
    &:hover {
      .mvs {
        opacity: 1;
      }
    }
  }
  p {
    text-align: left;
    font-size: 14px;
    line-height: 25px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
    &.mvname {
      color: #4a4a4a;
    }
    &.singername {
      color: #cdbec4;
    }
  }
}
</style>
