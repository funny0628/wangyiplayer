<template>
  <div class="tabel">
      <div class="top">
          <Taps
          :taps="taps"
          classname="detailtabel"
          />
          <p><i class="iconfont icon-"></i> <input type="text" placeholder="搜索歌单音乐"></p>
      </div>
  </div>
</template>

<script>
const taplist =["歌曲列表","评论"]
export default {
    data () {
        return {
          taps:taplist
        }
    }
}
</script>

<style lang="scss" scoped>
.tabel {
    .top {
        // height: 50px;
        border-bottom: 1px solid #ccc;
        background-color: pink;
        display: flex;
        position: relative;
        padding: 0px 15px;
        i {
            height: 48px;
            line-height: 48px;
            // border-bottom: 2px solid #d33a31;
            margin-right: 15px;

        }
        p {
            position: absolute;
            right: 0;
        }
    }
}

</style>