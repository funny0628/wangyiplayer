import Vue from 'vue'
import App from './App.vue'
import router from './router/index.js'
// import store from './store/index.js'
import './assets/styles/base.scss'
import './assets/styles/iconfont.css'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import request from './http/index.js'
import {global} from './utils/global.js'
Vue.prototype.$request = request;

Vue.config.productionTip = false
Vue.use(ElementUI);
Vue.use(global);

//处理最新音乐序号
Vue.filter('formatnumber',function(num){
  num++ 
  return num > 9 ? num : `0${num}`
})

//处理最新音乐多个歌手名字
Vue.filter('formatartis',function(list){
  let namelist = list.map(item=> item.name);
  return namelist.length > 1 ?  namelist.join('/') : namelist[0]
})

//处理最新音乐歌曲时长
Vue.filter('formatduration',function(time){
  return time
})

new Vue({
  router,
  // store,
  render: function (h) { return h(App) }
}).$mount('#app')
