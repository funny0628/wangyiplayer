//mv详情页面
<template>
  <div class="mv">
      mv详情页面
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>