//歌单详情
<template>
  <div class="playlistdetail">
    <Detailtop/>
    <Detailtabel/>
      
  </div>
</template>

<script>
import Detailtop from '../../comments/detail-top.vue'
import Detailtabel from '../../comments/detail-tabel.vue'
export default {
  components: {
    Detailtop,
    Detailtabel
  }
}
</script>

<style>

</style>