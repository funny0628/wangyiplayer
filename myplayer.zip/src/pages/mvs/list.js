export const local = {
    title:'地区',
    list:[
      {tap:"全部"},
      {tap:"内地"},
      {tap:"港台"},
      {tap:"欧美"},
      {tap:"日本"},
      {tap:"韩国"},
    ]
  }
export  const types = {
    title:'类型',
    list:[
      {tap:"全部"},
      {tap:"内地"},
      {tap:"官方版"},
      {tap:"原声"},
      {tap:"现场版"},
      {tap:"网易出品"},
    ]
  }
export  const sort = {
    title:'排序',
    list:[
      {tap:"上升最快"},
      {tap:"最热"},
      {tap:"最新"},
    ]
  }